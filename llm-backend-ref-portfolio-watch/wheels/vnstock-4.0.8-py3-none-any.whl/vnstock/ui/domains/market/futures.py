from typing import Any

from vnstock.ui._base import BaseDetailUI


class FuturesMarket(BaseDetailUI):
    """Futures market data."""

    def ohlcv(
        self,
        start: str = None,
        end: str = None,
        interval: str = "1D",
        count: int = 100,
        source: str = "kbs",
        **kwargs,
    ) -> Any:
        """Historical OHLCV bars for Futures."""
        # Handle parameter aliases
        interval = kwargs.pop("resolution", interval)
        count_back = kwargs.pop("length", count)
        return self._dispatch(
            "Market",
            "futures",
            "ohlcv",
            start=start,
            end=end,
            interval=interval,
            count_back=count_back,
            source=source,
            **kwargs,
        )

    def quote(self, source: str = "kbs", **kwargs) -> Any:
        """In-session pricing for Futures (source-delayed)."""
        return self._dispatch("Market", "futures", "quote", source=source, **kwargs)

    def trades(self, source: str = "kbs", **kwargs) -> Any:
        """Tick-by-tick trades for Futures."""
        # Handle interval clash
        kwargs.pop("interval", None)
        return self._dispatch("Market", "futures", "trades", source=source, **kwargs)
