"""Listing module."""

# Price chart, order-book depth chart, price-versus-volume chart and market behaviour statistics
from typing import Optional

import pandas as pd
from vnai import optimize_execution

from vnstock.core.utils.client import send_request
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.parser import camel_to_snake
from vnstock.core.utils.transform import drop_cols_by_pattern, reorder_cols
from vnstock.core.utils.user_agent import get_headers

from .const import _GROUP_CODE_MAPPING, _TRADING_URL, _VCI_INDEX_MAPPING

logger = get_logger(__name__)


class Listing:
    """Access historical price data from VCI."""

    def __init__(
        self,
        random_agent: Optional[bool] = False,
        show_log: Optional[bool] = False,
    ):
        self.data_source = "VCI"
        self.base_url = _TRADING_URL
        self.headers = get_headers(
            data_source=self.data_source, random_agent=random_agent
        )
        self.show_log = show_log

        if not show_log:
            logger.setLevel("CRITICAL")

    @optimize_execution("VCI")
    def all_symbols(self, show_log: Optional[bool] = False) -> pd.DataFrame:
        """Retrieve every ticker and company name on the Vietnamese market.

        Args:
            show_log: Show debug logs. Defaults to False.
        """
        try:
            df = self.symbols_by_exchange(show_log=show_log)
            df = df.query('type == "STOCK"').reset_index(drop=True)
            df = df[["symbol", "organ_name"]]
        except Exception as e:
            if show_log:
                logger.warning(
                    f"symbols_by_exchange thất bại, đang thử fallback sang symbols_by_industries: {e}"
                )
            # Fallback to industries listing which is more stable
            df = self.symbols_by_industries(show_log=show_log)
            # Filter unique symbols and ensure columns match
            df = df.drop_duplicates(subset=["symbol"]).reset_index(drop=True)
            df = df[["symbol", "organ_name"]]

        return df

    @optimize_execution("VCI")
    def symbols_by_industries(
        self, lang: str = "vi", show_log: Optional[bool] = False
    ) -> pd.DataFrame:
        """
        Retrieve the ICB industry classification for tickers on the Vietnamese market.

        Args:
            - lang (optional): Display language. Defaults to 'vi'.
            - show_log (optional): Show debug logs. Defaults to False.
        """
        if lang not in ["vi", "en"]:
            raise ValueError("Tham số lang phải là 'vi' hoặc 'en'.")

        lang_code = "1" if lang == "vi" else "2"
        url = f"https://iq.vietcap.com.vn/api/iq-insight-service/v2/company/search-bar?language={lang_code}"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            show_log=show_log,
        )

        if not json_data or "data" not in json_data or json_data["data"] is None:
            raise ValueError(
                "Không nhận được dữ liệu (data) từ VCI. Có thể API đã thay đổi cấu trúc (Did not receive data from VCI. API structure may have changed)"
            )

        if show_log:
            logger.info(
                "Truy xuất thành công dữ liệu danh sách phân ngành icb (Successfully retrieved ICB sector list data)."
            )

        parsed_data = []
        for company in json_data["data"]:
            symbol = company.get("code")
            organ_name = company.get("name")
            com_type_code = company.get("comTypeCode")

            for level in range(1, 5):
                icb_key = f"icbLv{level}"
                if icb_key in company and company[icb_key] is not None:
                    parsed_data.append(
                        {
                            "symbol": symbol,
                            "organ_name": organ_name,
                            "com_type_code": com_type_code,
                            "icb_level": level,
                            "icb_code": company[icb_key].get("code"),
                            "icb_name": company[icb_key].get("name"),
                        }
                    )

        df = pd.DataFrame(parsed_data)

        if not df.empty:
            # Filter out empty ICB codes
            df = df[df["icb_code"].notna() & (df["icb_code"] != "")]
            # Sort by symbol and level
            df = df.sort_values(by=["symbol", "icb_level"]).reset_index(drop=True)
            df = df[
                [
                    "symbol",
                    "organ_name",
                    "com_type_code",
                    "icb_level",
                    "icb_code",
                    "icb_name",
                ]
            ]

        df.source = "VCI"

        return df

    @optimize_execution("VCI")
    def symbols_by_exchange(
        self, lang: str = "vi", show_log: Optional[bool] = False
    ) -> pd.DataFrame:
        """
        Retrieve listing information by exchange for tickers on the Vietnamese market.

        Args:
            - lang (optional): Display language. Defaults to 'vi'.
            - show_log (optional): Show debug logs. Defaults to False.
        """
        if lang not in ["vi", "en"]:
            raise ValueError("Tham số lang phải là 'vi' hoặc 'en'.")

        url = self.base_url.rstrip("/") + "/price/symbols/getAll"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            payload=None,
            show_log=show_log,
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại.")

        if show_log:
            logger.info(
                f"Truy xuất dữ liệu thành công cho {len(json_data)} mã (Successfully retrieved data for {len(json_data)} symbols)."
            )

        df = (
            pd.DataFrame([json_data])
            if isinstance(json_data, dict)
            else pd.DataFrame(json_data)
        )

        df.columns = [camel_to_snake(col) for col in df.columns]
        df = df.rename(columns={"board": "exchange"})
        df = reorder_cols(df, ["symbol", "exchange", "type"], position="first")
        df = df.drop(columns=["id"])

        if lang == "vi":
            df = drop_cols_by_pattern(df, ["en_"])
        else:
            df = df.drop(columns=["organ_name", "organ_short_name"])
            # rename columns for those contain 'en_' with 'en_' removed
            df.columns = [col.replace("en_", "") for col in df.columns]

        # Set metadata attributes
        df.source = "VCI"
        return df

    @optimize_execution("VCI")
    def industries_icb(self, show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Retrieve the ICB industry classification for tickers on the Vietnamese market.

        Args:
            - show_log (optional): Show debug logs. Defaults to False.
        """
        url = "https://iq.vietcap.com.vn/api/iq-insight-service/v1/sectors/icb-codes"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            show_log=show_log,
        )

        if not json_data:
            raise ValueError("Không tìm thấy dữ liệu. Vui lòng kiểm tra lại.")

        if "data" not in json_data or json_data["data"] is None:
            raise ValueError(
                "Không nhận được dữ liệu (data) từ VCI. Có thể API đã thay đổi cấu trúc (Did not receive data from VCI. API structure may have changed)."
            )

        if show_log:
            logger.info(
                "Truy xuất thành công dữ liệu danh sách phân ngành icb (Successfully retrieved ICB sector list data)."
            )

        df = pd.DataFrame(json_data["data"])
        df = df.rename(
            columns={
                "name": "icb_code",
                "viSector": "icb_name",
                "enSector": "en_icb_name",
                "icbLevel": "level",
            }
        )

        if not df.empty:
            df = df[["icb_name", "en_icb_name", "icb_code", "level"]]
            df = df.sort_values(by=["icb_code"]).reset_index(drop=True)

        df.source = "VCI"

        return df

    @optimize_execution("VCI")
    def symbols_by_group(
        self, group: str = "VN30", show_log: Optional[bool] = False
    ) -> pd.Series:
        """
        Retrieve the tickers that belong to a named group.

        Args:
            - group (optional): Group name. Defaults to 'VN30'.
            - show_log (optional): Show debug logs. Defaults to False.
        """
        standardized_group = group.upper()
        if standardized_group in _VCI_INDEX_MAPPING:
            vci_group = _VCI_INDEX_MAPPING[standardized_group]
        elif standardized_group in _GROUP_CODE_MAPPING:
            vci_group = _GROUP_CODE_MAPPING[standardized_group]
        else:
            valid_keys = list(_GROUP_CODE_MAPPING.keys()) + list(
                _VCI_INDEX_MAPPING.keys()
            )
            raise ValueError(
                f"Invalid group '{group}'. Group must be one of {valid_keys}"
            )

        url = self.base_url.rstrip("/") + f"/price/symbols/getByGroup?group={vci_group}"

        # Use the send_request utility from api_client
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            payload=None,
            show_log=show_log,
        )

        if show_log:
            logger.info(
                "Truy xuất thành công dữ liệu danh sách mã theo nhóm (Successfully retrieved symbol list by group)."
            )

        df = pd.DataFrame(json_data)

        if not json_data:
            raise ValueError("JSON data is empty or not provided.")
        # Set metadata attributes
        df.source = "VCI"
        return df["symbol"]

    @optimize_execution("VCI")
    def all_future_indices(self, show_log: Optional[bool] = False) -> pd.Series:
        return self.symbols_by_group(group="FU_INDEX", show_log=show_log)

    @optimize_execution("VCI")
    def all_government_bonds(self, show_log: Optional[bool] = False) -> pd.Series:
        return self.symbols_by_group(group="FU_BOND", show_log=show_log)

    @optimize_execution("VCI")
    def all_covered_warrant(self, show_log: Optional[bool] = False) -> pd.Series:
        return self.symbols_by_group(group="CW", show_log=show_log)

    @optimize_execution("VCI")
    def all_bonds(self, show_log: Optional[bool] = False) -> pd.Series:
        return self.symbols_by_group(group="BOND", show_log=show_log)

    @optimize_execution("VCI")
    def market_status(self, show_log: Optional[bool] = False) -> pd.DataFrame:
        """Retrieve global market status from HOSE as reference."""
        from vnstock.core.utils.market import trading_hours

        status_dict = trading_hours("HOSE")
        df = pd.DataFrame([status_dict])
        df.source = "VCI"
        return df

    @optimize_execution("VCI")
    def search_symbol(
        self, query: str, show_log: Optional[bool] = False
    ) -> pd.DataFrame:
        """Search for symbols by filtering all_symbols list."""
        df = self.all_symbols(show_log=show_log)
        if query:
            query = query.upper()
            df = df[
                df["symbol"].astype(str).str.contains(query)
                | df["organ_name"].astype(str).str.upper().str.contains(query)
            ]
        df.source = "VCI"
        return df


# Register provider

from vnstock.core.registry import ProviderRegistry  # noqa: E402, F401

ProviderRegistry.register("listing", "vci", Listing)
