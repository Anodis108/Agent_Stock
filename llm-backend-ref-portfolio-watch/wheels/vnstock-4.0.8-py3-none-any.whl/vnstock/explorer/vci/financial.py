"""
Financial statement data from the VCI data source.
"""

import pandas as pd
from packaging import version


def _safe_infer_objects(df):
    """
    Call infer_objects the way the installed pandas expects.
    pandas >= 2.1.0 takes copy=False; older versions do not accept the argument.
    """
    if version.parse(pd.__version__) >= version.parse("2.1.0"):
        return df.infer_objects(copy=False)
    else:
        return df.infer_objects()


from typing import Dict, Optional, Union  # noqa: E402

import requests  # noqa: E402
from vnai import optimize_execution  # noqa: E402

from vnstock.core.utils import client  # noqa: E402
from vnstock.core.utils.logger import get_logger  # noqa: E402
from vnstock.core.utils.parser import get_asset_type  # noqa: E402
from vnstock.core.utils.user_agent import get_headers  # noqa: E402
from vnstock.core.utils.validation import validate_symbol  # noqa: E402

from .const import (  # noqa: E402
    _FINANCIAL_REPORT_PERIOD_MAP,
    _IQ_FINANCE_REPORT,
    _VCIQ_URL,
    SUPPORTED_LANGUAGES,
)

logger = get_logger(__name__)


class Finance:
    """
    Access a company's financial statements from the VCI data source.

    Args:
        - symbol (str): Ticker symbol of the company to look up.
        - period (str): Reporting period. Defaults to 'quarter'.
        - get_all (bool): Return every field instead of the curated subset. Defaults to True.
        - show_log (bool): Show debug logs. Defaults to True.
    """

    def __init__(
        self,
        symbol: str,
        period: Optional[str] = "quarter",
        get_all: Optional[bool] = True,
        show_log: Optional[bool] = True,
    ):
        """
        Initialise the Finance client.
        """
        self.symbol = validate_symbol(symbol)
        self.asset_type = get_asset_type(self.symbol)
        self.headers = get_headers(data_source="VCI")
        self.show_log = show_log
        self.base_url = _VCIQ_URL
        self._handshake()

        if not show_log:
            logger.setLevel("CRITICAL")

        # Validate input for period
        if period not in ["year", "quarter"]:
            raise ValueError(
                "Kỳ báo cáo tài chính không hợp lệ. Chỉ chấp nhận 'year' hoặc 'quarter'."
            )

        # If asset_type is not stock, raise error
        if self.asset_type not in ["stock"]:
            raise ValueError(
                "Mã chứng khoán không hợp lệ. Chỉ cổ phiếu mới có thông tin."
            )

        self.period = _FINANCIAL_REPORT_PERIOD_MAP.get(period)
        self.get_all = get_all
        self.com_type_code = self._get_company_type()

    def _get_company_type(self) -> str:
        """
        Look up the company type in ICB4_COMTYPE_CODE_MAP from the company's ICB4
        industry classification, which decides how the statements are mapped.

        Returns:
            str: One of
                'CT': ordinary company
                'CK': securities firm
                'NH': bank
                'BH': insurer
        """
        # Call the Listing module instead of Company._fetch_data (which relies on a deprecated API structure)
        from vnstock.explorer.vci.listing import Listing

        df_listing = Listing(random_agent=False, show_log=False).symbols_by_industries()
        if not df_listing.empty:
            df_match = df_listing[
                (df_listing["symbol"] == self.symbol) & (df_listing["icb_level"] == 4)
            ]
            if not df_match.empty:
                return df_match["com_type_code"].iloc[0]

        # Fallback value if not found
        return "CT"

    @staticmethod
    def duplicated_columns_handling(df_or_mapping, target_col_name=None):
        """
        Handle duplicated column names in a DataFrame or column mapping DataFrame.

        Parameters:
            - df_or_mapping (pd.DataFrame): Either a DataFrame with potentially duplicated columns
            or a mapping DataFrame with columns that may have duplicated values.
            - target_col_name (str, optional): When handling a mapping DataFrame, this is the column
            to check for duplicates. When None, assumes we're handling DataFrame columns directly.

        Returns:
            pd.DataFrame: DataFrame with resolved column duplications.
        """  # noqa: W293
        if target_col_name is not None:
            # Original behavior for handling mapping DataFrames
            # Duplicated subset
            duplicated_subset = df_or_mapping[
                df_or_mapping[target_col_name].duplicated()
            ].copy()
            # Non-duplicated subset
            non_duplicated_subset = df_or_mapping[
                ~df_or_mapping[target_col_name].duplicated()
            ].copy()
            # Replace values in the duplicated columns by appending the field_name
            duplicated_subset[target_col_name] = (
                df_or_mapping["name"] + " - " + df_or_mapping["field_name"]
            )
            # Combine the two subsets
            return pd.concat([non_duplicated_subset, duplicated_subset])
        else:
            # New behavior for handling DataFrame columns directly
            df = df_or_mapping.copy()
            # Find columns that have any duplicates at all
            duplicate_mask = df.columns.duplicated(keep=False)
            duplicated_col_names = df.columns[duplicate_mask].unique()

            if len(duplicated_col_names) > 0:
                # Create a new column mapping for rename operation
                new_columns = df.columns.tolist()

                for col_name in duplicated_col_names:
                    # Find all indices where this column name appears
                    indices = [
                        i for i, name in enumerate(new_columns) if name == col_name
                    ]

                    # Skip the first occurrence, only rename subsequent occurrences
                    for idx in indices[1:]:
                        new_col_name = f"_{col_name}"
                        # Check if the new name already exists or will be created
                        suffix_count = 1
                        while new_col_name in new_columns:
                            new_col_name = f"{'_' * (suffix_count + 1)}{col_name}"
                            suffix_count += 1

                        # Update the name in our new_columns list
                        new_columns[idx] = new_col_name

                # Apply the renaming
                df.columns = new_columns

    def _handshake(self):
        """
        Initiate the handshake that establishes a session.
        """
        url = "https://trading.vietcap.com.vn/priceboard"
        try:
            session = requests.Session()
            session.headers.update(self.headers)
            session.get(url, timeout=10)
            # Refresh the headers with the cookies handed out by the price board
            self.headers.update(session.cookies.get_dict())
        except Exception as e:
            if self.show_log:
                logger.warning(f"Handshake thất bại: {e}")

    def _get_ratio_dict(
        self,
        lang: str = "vi",
        format: str = "dict",
        style: str = "readable",
        show_log: Optional[bool] = False,
    ) -> Union[pd.DataFrame, Dict]:
        """
        Fetch the mapping dictionary for every financial ratio from the VCI microservices.

        Args:
            - lang (str): Report language, 'vi' or 'en'. Defaults to 'vi'.
            - format (str): Return shape, 'dict' or 'dataframe'. Defaults to 'dict'.
            - style (str): Column naming, 'readable' for full names or 'code' for technical codes. Defaults to 'readable'.
            - show_log (bool): Show debug logs. Defaults to False.

        Returns:
            Union[pd.DataFrame, Dict]: The mapping, shaped according to format.
        """  # noqa: W293
        # Validate lang
        if lang not in SUPPORTED_LANGUAGES:
            raise ValueError(
                f"Ngôn ngữ '{lang}' không hợp lệ. Chỉ chấp nhận {', '.join(SUPPORTED_LANGUAGES)}."
            )

        url = f"{self.base_url}/v1/company/{self.symbol}/financial-statement/metrics"

        if show_log:
            logger.debug(f"Requesting financial ratio data from {url}")

        # Use api_client.send_request instead of direct requests
        response_data = client.send_request(
            url=url,
            headers=self.headers,
            method="GET",
            payload=None,
            show_log=show_log,
        )

        data = response_data.get("data")
        if data is None:
            raise ValueError(
                f"Không nhận được dữ liệu metadata từ VCI cho mã {self.symbol}."
            )

        combine_ls = []
        for key in data.keys():
            df = pd.DataFrame(data[key])
            df["report_name"] = key
            df = df[
                [
                    "report_name",
                    "field",
                    "parent",
                    "titleEn",
                    "titleVi",
                    "fullTitleVi",
                    "fullTitleEn",
                ]
            ]
            combine_ls.append(df)

        df = pd.concat(combine_ls)
        df = df.rename(
            columns={
                "field": "field_name",
                "titleVi": "name",
                "titleEn": "en_name",
                "fullTitleVi": "full_name",
                "fullTitleEn": "en_full_name",
            }
        )

        if format == "dict":
            if lang == "vi":
                return df.set_index("field_name")["name"].to_dict()
            elif lang == "en":
                return df.set_index("field_name")["en_name"].to_dict()
        else:
            return df

    def _get_report(
        self,
        report_type: Union[str, None] = None,
        lang: Optional[str] = "en",
        show_log: Optional[bool] = False,
        mode: Optional[str] = "final",
        style: Optional[str] = "readable",
        get_all: Optional[bool] = False,
        period: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Fetch a financial statement from the VCI REST API, raw or already mapped.
        """
        # Baseline limit
        effective_limit = limit if limit is not None else 4
        # Validate report_type
        if report_type not in _IQ_FINANCE_REPORT.keys():
            raise ValueError(
                f"Loại báo cáo tài chính không hợp lệ: '{report_type}'. Hỗ trợ: {', '.join(_IQ_FINANCE_REPORT.keys())}"
            )

        report_section = _IQ_FINANCE_REPORT[report_type]

        if report_section == "RATIO":
            url = f"{self.base_url}/v1/company/{self.symbol}/statistics-financial"
            params = {}
        else:
            url = f"{self.base_url}/v1/company/{self.symbol}/financial-statement"
            params = {"section": report_section}

        if show_log:
            logger.debug(
                f"Requesting financial report data from {url}. params: {params}"
            )

        response_data = client.send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            payload=None,
            show_log=show_log,
        )

        data = response_data.get("data")
        if data is None:
            raise ValueError(
                f"Không nhận được dữ liệu (data) từ VCI cho mã {self.symbol} tại section {report_section}."
            )

        # Filter only requested period type
        effective_period = period if period else self.period
        # Map 'Y'/'Q' (internal) or 'year'/'quarter' (user) to VCI API keys
        target_key = "years" if effective_period in ["year", "Y"] else "quarters"

        if report_section == "RATIO":
            combined_df = pd.DataFrame(data)
        else:
            df_list = []  # noqa: F841
            # Only process the target period key from the response
            period_data = data.get(target_key, [])
            if period_data:
                combined_df = pd.DataFrame(period_data)
                # Keep tracking if it's year or quarter
                combined_df["report_period"] = target_key[:-1]
            else:
                combined_df = pd.DataFrame()

        # Apply limit
        if not combined_df.empty and len(combined_df) > effective_limit:
            combined_df = combined_df.head(effective_limit)

        if mode == "final":
            return self._ratio_mapping(
                report_df=combined_df,
                lang=lang,
                style=style,
                get_all=get_all,
                show_log=show_log,
                period_type=effective_period,
                report_type=report_type,
            )
        elif mode == "raw":
            return combined_df

    def _ratio_mapping(
        self,
        report_df: pd.DataFrame,
        lang: Optional[str] = "vi",
        style: str = "readable",
        get_all: Optional[bool] = False,
        show_log: Optional[bool] = False,
        period_type: Optional[str] = None,
        report_type: Optional[str] = None,
    ):
        if report_type and report_type.upper() == "RATIO":
            from vnstock.explorer.vci.const import (
                RATIO_COLUMN_MAP_EN,
                RATIO_COLUMN_MAP_SNAKE,
                RATIO_COLUMN_MAP_VI,
            )

            vi_dict = RATIO_COLUMN_MAP_VI
            en_dict = RATIO_COLUMN_MAP_EN
            snake_dict = RATIO_COLUMN_MAP_SNAKE
        else:
            # Get metadata mapping for both languages
            meta_df = self._get_ratio_dict(format="dataframe", show_log=show_log)
            vi_dict = meta_df.set_index("field_name")["name"].to_dict()
            en_dict = meta_df.set_index("field_name")["en_name"].to_dict()
            snake_dict = None

        try:
            # Identify which columns are items vs metadata
            item_cols = [col for col in report_df.columns if col in vi_dict]

            # Create period labels if not already present
            if "period" not in report_df.columns:
                # VCI logic for year/quarter
                y_col = (
                    "year"
                    if "year" in report_df.columns
                    else ("yearReport" if "yearReport" in report_df.columns else None)
                )
                q_col = (
                    "quarter"
                    if "quarter" in report_df.columns
                    else (
                        "lengthReport" if "lengthReport" in report_df.columns else None
                    )
                )

                if y_col and q_col:

                    def fmt_period(row):
                        try:
                            y = int(row[y_col])
                            q = int(row[q_col])
                            return (
                                f"{y}-Q{q}"
                                if q < 5 and period_type in ["quarter", "Q"]
                                else f"{y}"
                            )
                        except:  # noqa: E722
                            return "N/A"

                    report_df["period"] = report_df.apply(fmt_period, axis=1)
                elif y_col:
                    report_df["period"] = report_df[y_col].astype(str)
                elif "report_period" in report_df.columns:
                    report_df["period"] = report_df["report_period"]

            # We want to return Items as rows and Periods as columns (match KBS)
            if "period" in report_df.columns:
                # Drop metadata columns that are NOT the items or period
                cols_to_keep = ["period"] + item_cols
                processed_df = report_df[cols_to_keep].copy()

                # Set period as index then transpose
                processed_df = processed_df.set_index("period").T

                # Now Rows are our items (codes). Let's add readable labels.
                processed_df.index.name = "item_id"
                processed_df = processed_df.reset_index()

                processed_df["item"] = processed_df["item_id"].map(vi_dict)
                processed_df["item_en"] = processed_df["item_id"].map(en_dict)

                # Normalize item_id to match snake_case convention
                if snake_dict:
                    processed_df["item_id"] = processed_df["item_id"].map(
                        lambda x: snake_dict.get(x, x)
                    )
                else:
                    try:
                        from vnstock.core.utils.field.handler import FieldHandler

                        field_handler = FieldHandler()
                        # Fallback to normalized English name if available, otherwise original id
                        processed_df["item_id"] = processed_df["item_en"].apply(
                            lambda x: (
                                field_handler.normalize_field_name(x, language="en")
                                if pd.notna(x)
                                else x
                            )
                        )
                    except ImportError:
                        pass

                # Reorder columns: metadata first, then periods
                period_cols = [
                    c
                    for c in processed_df.columns
                    if c not in ["item", "item_en", "item_id"]
                ]
                # Use original order for columns
                processed_df = processed_df[
                    ["item", "item_en", "item_id"] + period_cols
                ]

                return processed_df
        except Exception as e:
            if show_log:
                import logging

                logging.getLogger(__name__).warning(
                    f"Lỗi khi mapping dữ liệu (có thể do phiên bản Pandas cũ): {e}. Trả về dữ liệu gốc."
                )

        return report_df

    def _get_financial_report(
        self,
        report_type: str,
        period: Optional[str] = None,
        lang: Optional[str] = "en",
        mode: Optional[str] = "final",
        style: Optional[str] = "readable",
        get_all: Optional[bool] = False,
        dropna: Optional[bool] = True,
        show_log: Optional[bool] = False,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Internal entry point for fetching a financial statement.
        """
        df = self._get_report(
            report_type=report_type,
            lang=lang,
            mode=mode,
            style=style,
            get_all=get_all,
            show_log=show_log,
            limit=limit,
            period=period,
        )

        if df.empty:
            return df

        # Filter by period if requested
        if period in ["year", "quarter"]:
            # This is a bit complex as REST returns multiple periods.
            # For simplicity, we just filter the resulting df if 'report_period' exists
            pass

        if dropna:
            df = _safe_infer_objects(df.fillna(0))
            df = df.loc[:, (df != 0).any(axis=0)]

        return df

    @optimize_execution("VCI")
    def balance_sheet(
        self,
        period: Optional[str] = None,
        lang: Optional[str] = "en",
        dropna: Optional[bool] = True,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve the balance sheet from the VCI REST API.

        Args:
            - period (str): Report period, 'year' or 'quarter'. Defaults to whatever was set on the client.
            - lang (str): Language, 'vi' or 'en'. Defaults to 'en'.
            - dropna (bool): Drop columns whose values are all zero. Defaults to True.
            - show_log (bool): Show debug logs. Defaults to False.

        Returns:
            pd.DataFrame: The balance sheet, indexed by reporting period.
        """
        return self._get_financial_report(
            "balance_sheet", period=period, lang=lang, dropna=dropna, show_log=show_log
        )

    @optimize_execution("VCI")
    def income_statement(
        self,
        period: Optional[str] = None,
        lang: Optional[str] = "en",
        dropna: Optional[bool] = True,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve the income statement from the VCI REST API.

        Args:
            - period (str): Report period, 'year' or 'quarter'.
            - lang (str): Language, 'vi' or 'en'.
            - dropna (bool): Drop all-zero columns.
            - show_log (bool): Show logs.

        Returns:
            pd.DataFrame: The income statement.
        """
        return self._get_financial_report(
            "income_statement",
            period=period,
            lang=lang,
            dropna=dropna,
            show_log=show_log,
        )

    @optimize_execution("VCI")
    def cash_flow(
        self,
        period: Optional[str] = None,
        lang: Optional[str] = "en",
        dropna: Optional[bool] = True,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve the cash flow statement from the VCI REST API.

        Args:
            - period (str): Report period, 'year' or 'quarter'.
            - lang (str): Language, 'vi' or 'en'.
            - dropna (bool): Drop all-zero columns.
            - show_log (bool): Show logs.

        Returns:
            pd.DataFrame: The cash flow statement.
        """
        return self._get_financial_report(
            "cash_flow", period=period, lang=lang, dropna=dropna, show_log=show_log
        )

    @optimize_execution("VCI")
    def ratio(
        self,
        period: Optional[str] = None,
        lang: Optional[str] = "en",
        dropna: Optional[bool] = True,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve the financial ratios from the VCI REST API.

        Args:
            - period (str): Report period, 'year' or 'quarter'.
            - lang (str): Language, 'vi' or 'en'.
            - dropna (bool): Drop all-zero columns.
            - show_log (bool): Show logs.

        Returns:
            pd.DataFrame: The financial ratios.
        """
        return self._get_financial_report(
            "ratio", period=period, lang=lang, dropna=dropna, show_log=show_log
        )


# Register provider
from vnstock.core.registry import ProviderRegistry  # noqa: E402, F401

ProviderRegistry.register("financial", "vci", Finance)
