"""Constants for KB Securities (KBS) data source."""

# Base URLs
_IIS_BASE_URL = "https://kbbuddywts.kbsec.com.vn/iis-server/investment"
_SAS_BASE_URL = "https://kbbuddywts.kbsec.com.vn/sas"

# IIS Server Endpoints - Listing & Market Data
_SEARCH_URL = f"{_IIS_BASE_URL}/stock/search/data"
_SECTOR_ALL_URL = f"{_IIS_BASE_URL}/sector/all"
_SECTOR_STOCK_URL = f"{_IIS_BASE_URL}/sector/stock"
_STOCK_INFO_URL = f"{_IIS_BASE_URL}/stockinfo"
_STOCK_TRADE_HISTORY_URL = f"{_IIS_BASE_URL}/trade/history"
_STOCK_MATCHED_BY_PRICE_URL = f"{_IIS_BASE_URL}/stock/matched-by-price"
# Index URL for listing/groups
_INDEX_URL = f"{_IIS_BASE_URL}/index"

# IIS Server Endpoints - Price Board (ISS)
_STOCK_ISS_URL = f"{_IIS_BASE_URL}/stock/iss"

# IIS Server Endpoints - Rankings
_RANKING_VOLUME_URL = f"{_IIS_BASE_URL}/rtranking/volume"
_RANKING_FOREIGN_URL = f"{_IIS_BASE_URL}/rtranking/foreignTotal"

# SAS Endpoints - Stock Data Store
_SAS_STOCK_URL = f"{_SAS_BASE_URL}/kbsv-stock-data-store/stock"
_SAS_HISTORICAL_QUOTES_URL = f"{_SAS_STOCK_URL}/{{symbol}}/historical-quotes"
_SAS_FINANCE_INFO_URL = f"{_IIS_BASE_URL}/stock/finance-info"
_SAS_TRADING_MARGIN_URL = f"{_SAS_STOCK_URL}/trading-margin"
_SAS_CTKH_INFO_URL = f"{_SAS_STOCK_URL}/ctkh-info"

# SAS Endpoints - News
_SAS_NEWS_URL = f"{_SAS_BASE_URL}/kbsv-news/api/v2/news"

# Index Mapping (Strictly supported indices)
_INDEX_MAPPING = {
    "VNINDEX": "VNINDEX",
    "HNXINDEX": "HNXINDEX",
    "UPCOMINDEX": "UPCOMINDEX",
    "VN30": "VN30",
    "HNX30": "HNX30",
    "VN100": "VN100",
}

# Group codes mapping
_GROUP_CODE = {
    "HOSE": "HOSE",
    "HNX": "HNX",
    "UPCOM": "UPCOM",
    "VN30": "30",
    "VN100": "100",
    "VNMidCap": "MID",
    "VNSmallCap": "SML",
    "VNSI": "SI",
    "VNX50": "X50",
    "VNXALL": "XALL",
    "VNALL": "ALL",
    "HNX30": "HNX30",
    "ETF": "FUND",
    "CW": "CW",
    "BOND": "BOND",
    "FU_INDEX": "DER",
}

# Exchange mapping for standardization
_EXCHANGE_MAP = {
    "HOSE": "HOSE",
    "HNX": "HNX",
    "UPCOM": "UPCOM",
}

# Industry codes mapping (from KBS API response)
_INDUSTRY_CODE = {
    1: "Bán buôn",
    2: "Bảo hiểm",
    3: "Bất động sản",
    5: "Chứng khoán",
    6: "Công nghệ và thông tin",
    7: "Bán lẻ",
    8: "Chăm sóc sức khỏe",
    10: "Khai khoáng",
    11: "Ngân hàng",
    12: "Nông - Lâm - Ngư",
    15: "SX Thiết bị, máy móc",
    16: "SX Hàng gia dụng",
    17: "Sản phẩm cao su",
    18: "SX Nhựa - Hóa chất",
    19: "Thực phẩm - Đồ uống",
    20: "Chế biến Thủy sản",
    21: "Vật liệu xây dựng",
    22: "Tiện ích",
    23: "Vận tải - kho bãi",
    24: "Xây dựng",
    25: "Dịch vụ lưu trú, ăn uống, giải trí",
    26: "SX Phụ trợ",
    27: "Thiết bị điện",
    28: "Dịch vụ tư vấn, hỗ trợ",
    29: "Tài chính khác",
}

# Column mapping for historical data (data_day)
_OHLC_MAP = {
    "t": "time",
    "o": "open",
    "h": "high",
    "l": "low",
    "c": "close",
    "v": "volume",
}

# Data type mapping for OHLC data
_OHLC_DTYPE = {
    "time": "datetime64[ns]",
    "open": "float64",
    "high": "float64",
    "low": "float64",
    "close": "float64",
    "volume": "int64",
}

# Column mapping for stock profile
_PROFILE_MAP = {
    "SM": "business_model",
    "SB": "symbol",
    "FD": "founded_date",
    "CC": "charter_capital",
    "HM": "num_employees",
    "LD": "listing_date",
    "FV": "par_value",
    "EX": "exchange",
    "LP": "listing_price",
    "VL": "listed_volume",
    "CTP": "ceo_name",
    "CTPP": "ceo_position",
    "IS": "inspector_name",
    "ISP": "inspector_position",
    "FP": "license_number",
    "BP": "business_code",
    "TC": "tax_code",
    "KT": "auditor",
    "TY": "company_type",
    "ADD": "address",
    "PHONE": "phone",
    "FAX": "fax",
    "EMAIL": "email",
    "URL": "website",
    "HS": "history",
}

# Event type IDs
_EVENT_TYPE = {
    1: "Đại hội cổ đông",
    2: "Trả cổ tức",
    3: "Phát hành",
    4: "Giao dịch cổ đông nội bộ",
    5: "Sự kiện khác",
}

# Interval mapping for technical chart data (KBS API)
# Maps user-friendly intervals to KBS API endpoint suffixes
_INTERVAL_MAP = {
    # Minute intervals
    "1m": "1P",  # 1 minute
    "5m": "5P",  # 5 minutes
    "15m": "15P",  # 15 minutes (not in sample but likely supported)
    "30m": "30P",  # 30 minutes
    # Hour intervals
    "1h": "60P",  # 1 hour (60 minutes)
    "1H": "60P",  # 1 hour (60 minutes) - uppercase alias
    "60m": "60P",  # 60 minutes
    # Daily intervals
    "1d": "day",  # 1 day
    "1D": "day",  # 1 day - uppercase alias
    "d": "day",  # 1 day - short alias
    "D": "day",  # 1 day - uppercase short alias
    "daily": "day",  # 1 day - word alias
    # Weekly intervals
    "1w": "week",  # 1 week
    "1W": "week",  # 1 week - uppercase alias
    "w": "week",  # 1 week - short alias
    "W": "week",  # 1 week - uppercase short alias
    "weekly": "week",  # 1 week - word alias
    # Monthly intervals
    "1M": "month",  # 1 month
    "m": "month",  # 1 month - short alias
    "M": "month",  # 1 month - uppercase short alias
    "monthly": "month",  # 1 month - word alias
}

# Resample mapping for data standardization
# Maps intervals to pandas resample frequency strings
_RESAMPLE_MAP = {
    # Minute intervals
    "1m": "1min",
    "5m": "5min",
    "15m": "15min",
    "30m": "30min",
    # Hour intervals
    "1h": "1H",
    "1H": "1H",
    "60m": "1H",
    # Daily intervals
    "1d": "1D",
    "1D": "1D",
    "d": "1D",
    "D": "1D",
    "daily": "1D",
    # Weekly intervals
    "1w": "1W",
    "1W": "1W",
    "w": "1W",
    "W": "1W",
    "weekly": "1W",
    # Monthly intervals
    "1M": "1MS",
    "m": "1MS",
    "M": "1MS",
    "monthly": "1MS",
}

# Column mapping for price board (ISS endpoint)
# Maps KBS API fields to schema-aligned field names (PriceBoardCore/Extended)
_PRICE_BOARD_MAP = {
    "TT": "volume_accumulated",  # CORRECTED: TT = total accumulated volume (not total_trades)
    "CV": "volume_last",  # CORRECTED: CV = current volume (last matched volume)
    # ⚠️  KBS grouping differs from VCI (each provider aggregates ATC orders differently)
    "PP": "price_points",
    "HI": "high_price",
    "TV": "total_value",  # CORRECTED: TV = total value (accumulated, unit VND)
    "LO": "low_price",
    "LS": "listed_shares",
    "CHP": "percent_change",
    "V1": "bid_vol_1",
    "V2": "bid_vol_2",
    "V3": "bid_vol_3",
    "B1": "bid_price_1",
    "AP": "average_price",
    "B2": "bid_price_2",
    "B3": "bid_price_3",
    "RE": "reference_price",
    "EX": "exchange",
    "FB": "foreign_buy_volume",
    "FC": "foreign_buy_count",
    "S1": "ask_price_1",
    "S2": "ask_price_2",
    "S3": "ask_price_3",
    "FL": "floor_price",
    "FO": "foreign_ownership_ratio",
    "FS": "foreign_sell_volume",  # FS raw key = foreign sell volume
    "PTQ": "put_through_qty",
    "FR": "foreign_room",  # FR raw key = foreign room
    "SB": "symbol",
    "PTV": "put_through_value",
    "TLQ": "total_listed_qty",
    "OP": "open_price",
    "CH": "price_change",
    "CL": "ceiling_price",
    "CP": "close_price",
    "TB": "total_buy_vol",
    "PMP": "previous_match_price",
    "CV": "current_vol",  # noqa: F601
    "t": "time",
    "PMQ": "previous_match_qty",
    "TO": "total_offer_vol",
    "U1": "ask_vol_1",
    "U2": "ask_vol_2",
    "U3": "ask_vol_3",
    "MS": "market_status",
    "OI": "open_interest",  # Open Interest for derivatives
}

# Column mapping for intraday trade history (in-session matching data)
# Maps KBS API fields to standardized column names
_INTRADAY_MAP = {
    "t": "timestamp",  # Full timestamp (YYYY-MM-DD HH:MM:SS:MS)
    "TD": "trading_date",  # Trading date (DD/MM/YYYY)
    "SB": "symbol",  # Stock symbol
    "FT": "time",  # Trade time (HH:MM:SS)
    "LC": "side",  # Trade side: 'B' (buy) or 'S' (sell)
    "FMP": "price",  # Match price
    "FCV": "price_change",  # Price change from previous
    "FV": "match_volume",  # Match volume
    "AVO": "accumulated_volume",  # Accumulated volume
    "AVA": "accumulated_value",  # Accumulated value
}

# Data type mapping for intraday data
_INTRADAY_DTYPE = {
    "timestamp": "object",
    "trading_date": "object",
    "symbol": "object",
    "time": "object",
    "side": "object",
    "price": "float64",
    "price_change": "float64",
    "match_volume": "int64",
    "accumulated_volume": "int64",
    "accumulated_value": "float64",
}

# VCI-equivalent core columns for intraday (standardized output)
# Matches VCI's core intraday columns: time, price, volume, match_type, id
_INTRADAY_CORE_COLUMNS = ["time", "price", "volume", "match_type", "id"]

# Column mapping for trade history
_TRADE_HISTORY_MAP = {
    "t": "timestamp",
    "TD": "trading_date",
    "SB": "symbol",
    "FT": "time",
    "LC": "side",  # 'B' for buy, 'S' for sell
    "FMP": "price",
    "FCV": "volume",
    "FV": "match_volume",
    "AVO": "accumulated_volume",
    "AVA": "accumulated_value",
}

# Column mapping for matched by price
_MATCHED_BY_PRICE_MAP = {
    "price": "price",
    "buy_vol": "buy_volume",
    "sell_vol": "sell_volume",
    "unknown_vol": "unknown_volume",
    "total_vol": "total_volume",
}

# Standard columns for price board output
# Mapped to the trading.PriceBoardCore/Extended schema
# Includes bid/ask prices and volumes as CORE fields (standard for price boards)
# Note: KBS API provides close_price as current match price, total_trades as volume
_PRICE_BOARD_STANDARD_COLUMNS = [
    "symbol",  # Ticker symbol
    "time",  # Timestamp
    "exchange",  # Exchange
    "ceiling_price",  # Ceiling price
    "floor_price",  # Floor price
    "reference_price",  # Reference price
    "open_price",  # Open
    "high_price",  # High
    "low_price",  # Low
    "close_price",  # Close, i.e. the current matched price
    "volume_last",  # Volume of the last matched trade (raw field "Khớp lệnh -> KL")
    "average_price",  # Average price
    "volume_accumulated",  # ⭐ Accumulated volume (from raw TT field)
    "total_value",  # Total traded value
    "price_change",  # Price change
    "percent_change",  # Percent change
    "bid_price_1",  # Bid price, level 1 (CORE)
    "bid_vol_1",  # Bid volume, level 1 (CORE)
    "bid_price_2",  # Bid price, level 2 (CORE)
    "bid_vol_2",  # Bid volume, level 2 (CORE)
    "bid_price_3",  # Bid price, level 3 (CORE)
    "bid_vol_3",  # Bid volume, level 3 (CORE)
    "ask_price_1",  # Ask price, level 1 (CORE)
    "ask_vol_1",  # Ask volume, level 1 (CORE)
    "ask_price_2",  # Ask price, level 2 (CORE)
    "ask_vol_2",  # Ask volume, level 2 (CORE)
    "ask_price_3",  # Ask price, level 3 (CORE)
    "ask_vol_3",  # Ask volume, level 3 (CORE)
    "foreign_buy_volume",  # Foreign buy volume
    "foreign_sell_volume",  # Foreign sell volume
    "foreign_room",  # ⭐ Foreign investor room (from raw FR field)
]

# Mapping from KBS API fields to the schema fields
_KBS_TO_SCHEMA_MAP = {
    # Price Board (stock) mappings
    "SB": "symbol",
    "t": "time",
    "EX": "exchange",
    "CL": "ceiling_price",
    "FL": "floor_price",
    "RE": "reference_price",
    "CP": "match_price",
    "CV": "match_volume",
    "OP": "open_price",
    "HI": "high_price",
    "LO": "low_price",
    "AP": "average_price",
    "TV": "total_value",
    "CH": "price_change",
    "CHP": "percent_change",
    "FB": "foreign_buy_volume",
    "FR": "foreign_sell_volume",
    "ST": "trading_status",
    "TT": "total_trades",
    "TD": "trading_date",
    # Put-through mappings
    "PR": "match_price",
    "MVL": "match_volume",
    "TI": "time",
    "MC": "exchange",
}

# Columns to exclude from get_all output (unclear/meaningless fields)
# These are KBS API fields that don't have clear meaning or are internal codes
_EXCLUDED_COLUMNS = {
    "ULS",  # Unknown/unclear field
    "IN",  # Internal code (e.g., 'ASB', 'VCH')
    "OIC",  # Unknown/unclear field
    "TSI",  # Unknown/unclear field
    "EP",  # Unknown/unclear field (always 0.0)
    "ER",  # Unknown/unclear field
    "FTY",  # Unknown/unclear field
    "P1",  # Unclear price field
    "P2",  # Unclear price field (duplicate of bid_price_1)
    "price_points",  # Always 0
    "total_buy_vol",  # Always 0
    "total_offer_vol",  # Always 0
    "previous_match_price",  # Not useful for current board
    "previous_match_qty",  # Not useful for current board
    "current_vol",  # Unclear/redundant
    "market_status",  # Single character code (O, C, etc.)
}

# Exchange code normalization mapping
# Normalize exchange codes to HOSE standard (used in API inputs)
_EXCHANGE_CODE_MAP = {
    "HOSE": "HOSE",  # Ho Chi Minh Stock Exchange
    "HSX": "HOSE",  # Old VCI code - normalize to HOSE
    "HNX": "HNX",  # Ha Noi Stock Exchange
    "XHNF": "HNX",  # KBS derivative exchange code - map to HNX
    "UPCOM": "UPCOM",  # Unlisted Public Company Market
}

# Company profile data mapping from API response
# Maps API field codes to standardized column names
_COMPANY_PROFILE_MAP = {
    "SM": "business_model",
    "SB": "symbol",
    "FD": "founded_date",
    "CC": "charter_capital",
    "HM": "number_of_employees",
    "LD": "listing_date",
    "FV": "par_value",
    "EX": "exchange",
    "LP": "listing_price",
    "VL": "listed_volume",
    "CTP": "ceo_name",
    "CTPP": "ceo_position",
    "IS": "inspector_name",
    "ISP": "inspector_position",
    "FP": "establishment_license",
    "BP": "business_code",
    "TC": "tax_id",
    "KT": "auditor",
    "TY": "company_type",
    "ADD": "address",
    "PHONE": "phone",
    "FAX": "fax",
    "EMAIL": "email",
    "URL": "website",
    "BRANCH": "branches",
    "HS": "history",
    "KLCPNY": "free_float_percentage",
    "SFV": "free_float",
    "KLCPLH": "outstanding_shares",
    "AD": "as_of_date",
}

# Subsidiaries data mapping
_SUBSIDIARIES_MAP = {
    "D": "update_date",
    "NM": "name",
    "CC": "charter_capital",
    "OR": "ownership_percent",
    "CR": "currency",
}

# Leaders data mapping
_LEADERS_MAP = {
    "FD": "from_date",
    "PN": "position",
    "NM": "name",
    "PO": "position_en",
    "PI": "owner_code",
}

# Ownership structure mapping
_OWNERSHIP_MAP = {
    "NM": "owner_type",
    "OR": "ownership_percentage",
    "SH": "shares_owned",
    "D": "update_date",
}

# Major shareholders mapping
_SHAREHOLDERS_MAP = {
    "NM": "name",
    "D": "update_date",
    "V": "shares_owned",
    "OR": "ownership_percentage",
}

# Charter capital history mapping
_CHARTER_CAPITAL_MAP = {
    "D": "date",
    "V": "charter_capital",
    "C": "currency",
}

# Labor structure mapping
_LABOR_STRUCTURE_MAP = {
    "Name": "name",
    "NameEn": "name_en",
    "Value": "value",
    "Rate": "rate",
}

# ============================================================================
# FINANCIAL DATA MAPPINGS - Schema Standardization
# ============================================================================

# Income Statement (KQKD) mapping
_INCOME_STATEMENT_MAP = {
    "operating_income": "revenue",
    "net_revenue": "revenue",
    "gross_profit": "gross_profit",
    "operating_profit": "operating_profit",
    "profit_before_tax": "profit_before_tax",
    "net_profit_after_tax": "net_profit",
    "cost_of_goods_sold": "cost_of_goods_sold",
    "selling_expenses": "selling_expenses",
    "general_and_administrative_expenses": "admin_expenses",
    "financial_expenses": "finance_expenses",
    "other_income": "other_income",
    "other_expenses": "other_expenses",
    "eps": "eps",
}

# Balance Sheet (CDKT) mapping
_BALANCE_SHEET_MAP = {
    "assets": "total_assets",
    "total_assets": "total_assets",
    "short_term_assets": "current_assets",
    "current_assets": "current_assets",
    "fixed_assets": "fixed_assets",
    "liabilities": "total_liabilities",
    "total_liabilities": "total_liabilities",
    "short_term_liabilities": "current_liabilities",
    "current_liabilities": "current_liabilities",
    "long_term_liabilities": "long_term_liabilities",
    "non_current_liabilities": "long_term_liabilities",
    "owners_equity": "equity",
    "share_capital": "charter_capital",
    "undistributed_earnings_after_tax": "retained_earnings",
}

# Cash Flow (LCTT) mapping
_CASH_FLOW_MAP = {
    "net_cash_flows_from_operating_activities": "operating_cash_flow",
    "net_cash_flows_from_investing_activities": "investing_cash_flow",
    "net_cash_flows_from_financing_activities": "financing_cash_flow",
    "net_increase_decrease_in_cash_and_cash_equivalents": "net_change_in_cash",
    "cash_and_cash_equivalents_at_beginning_of_period": "beginning_cash",
    "cash_and_cash_equivalents_at_end_of_period": "ending_cash",
}

# Financial Ratios (CSTC) mapping
_FINANCIAL_RATIOS_MAP = {
    "p_e": "pe_ratio",
    "p_b": "pb_ratio",
    "p_s": "ps_ratio",
    "roe": "roe",
    "roa": "roa",
    "gross_profit_margin": "gross_margin",
    "net_profit_margin": "net_margin",
    "current_ratio": "current_ratio",
    "quick_ratio": "quick_ratio",
    "debt_equity": "debt_to_equity",
    "liabilities_assets": "debt_to_assets",
    "book_value_per_share": "book_value_per_share",
    "earnings_per_share": "earnings_per_share",
}

# Financial report type mapping
_FINANCIAL_REPORT_TYPE_MAP = {
    "CDKT": "balance_sheet",
    "KQKD": "income_statement",
    "LCTT": "cash_flow",
    "CSTC": "financial_ratios",
    "CTKH": "planned_indicators",
    "BCTT": "summary_financial_report",
}

# Known Content keys returned by the KBS financial API, per report type.
# KBS renames these labels from time to time (e.g. "Cân đối kế toán" became
# "Báo cáo tình hình tài chính" in 2026), so each report type lists every key
# we have observed, newest first. The parser tries them in order.
_FINANCIAL_REPORT_KEY_ALIASES = {
    "CDKT": ("Báo cáo tình hình tài chính", "Cân đối kế toán"),
    "KQKD": ("Kết quả kinh doanh",),
    "LCTT": ("Lưu chuyển tiền tệ gián tiếp", "Lưu chuyển tiền tệ trực tiếp"),
}

# Financial period type mapping
_FINANCIAL_PERIOD_TYPE_MAP = {
    1: "year",
    2: "quarter",
}
