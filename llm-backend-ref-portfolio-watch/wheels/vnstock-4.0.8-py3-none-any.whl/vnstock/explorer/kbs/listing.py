"""Listing module for KB Securities (KBS) data source."""

from typing import Dict, List, Optional

import pandas as pd
from vnai import optimize_execution

from vnstock.core.utils.client import send_request
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.user_agent import get_headers
from vnstock.explorer.kbs.const import (
    _GROUP_CODE,
    _IIS_BASE_URL,
    _INDEX_URL,
    _SEARCH_URL,
    _SECTOR_ALL_URL,
    _SECTOR_STOCK_URL,
)

logger = get_logger(__name__)


class Listing:
    """
    Access the securities listing data published by KB Securities (KBS).
    """

    def __init__(
        self,
        random_agent: Optional[bool] = False,
        show_log: Optional[bool] = False,
    ):
        """
        Initialise the KBS Listing client.

        Args:
            random_agent: Deprecated and ignored. Defaults to False.
            show_log: Show debug logs. Defaults to False.
        """
        self.data_source = "KBS"
        self.base_url = _IIS_BASE_URL
        self.headers = get_headers(
            data_source=self.data_source, random_agent=random_agent
        )
        self.show_log = show_log

        if not show_log:
            logger.setLevel("CRITICAL")

    @optimize_execution("KBS")
    def all_symbols(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve every ticker listed on the Vietnamese market, as published by KBS.

        Returns a flat DataFrame mapping symbol to organ_name (the company name in Vietnamese).

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            DataFrame with two columns: symbol and organ_name.
            The source name is kept in df.attrs['source'].

        Examples:
            >>> kbs = Listing()
            >>> df = kbs.all_symbols()
            >>> print(df.columns.tolist())
            ['symbol', 'organ_name']
            >>> print(df.attrs['source'])
            'KBS'
        """
        # Get full stock data from API
        try:
            stocks_data = self._get_full_stock_data(show_log=show_log)
        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy dữ liệu chứng khoán: {str(e)}")
            return pd.DataFrame(columns=["symbol", "organ_name"])

        if not stocks_data:
            return pd.DataFrame(columns=["symbol", "organ_name"])

        # Convert to DataFrame
        df = pd.DataFrame(stocks_data).query("type == 'stock'")

        # Map 'name' to 'organ_name'
        if "name" in df.columns:
            df = df.rename(columns={"name": "organ_name"})

        # Keep only symbol, organ_name, and type columns
        df = df[["symbol", "organ_name"]]

        # Add source as attribute
        df.attrs["source"] = self.data_source

        if show_log:
            logger.info(f"Truy xuất thành công {len(df)} mã chứng khoán.")

        return df

    @optimize_execution("KBS")
    def symbols_by_exchange(
        self,
        get_all: Optional[bool] = False,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve tickers grouped by exchange.

        Uses the /stock/search/data endpoint, which returns the full record.

        Args:
            get_all: Return every column the API provides instead of the standardised subset. Defaults to False.
            show_log: Show debug logs. Defaults to False.

        Returns:
            DataFrame with the columns KBS provides: symbol, organ_name, en_organ_name,
            exchange, type, id, re, ceiling, floor.
            The source name is kept in df.attrs['source'].
            Columns the API omits are skipped.
        """
        # Get full stock data from API
        try:
            stocks_data = self._get_full_stock_data(show_log=show_log)
        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy dữ liệu chứng khoán: {str(e)}")
            return pd.DataFrame(columns=["symbol", "organ_name", "exchange", "source"])

        if not stocks_data:
            return pd.DataFrame(columns=["symbol", "organ_name", "exchange", "source"])

        # Convert to DataFrame
        df = pd.DataFrame(stocks_data)

        # Map KBS columns to standard names (similar to VCI)
        column_mapping = {
            "name": "organ_name",
            "nameEn": "en_organ_name",
            "index": "id",
        }
        df = df.rename(columns=column_mapping)

        # Define standard columns and filter by availability
        if get_all:
            standard_cols = [
                "symbol",
                "organ_name",
                "en_organ_name",
                "exchange",
                "type",
                "id",
                "re",
                "ceiling",
                "floor",
            ]
            available_cols = [col for col in standard_cols if col in df.columns]
        else:
            available_cols = [
                "symbol",
                "organ_name",
                "en_organ_name",
                "exchange",
                "type",
                "id",
            ]
        df = df[available_cols]
        df.attrs["source"] = self.data_source

        if show_log:
            logger.info(f"Truy xuất thành công {len(df)} mã chứng khoán theo sàn.")

        return df

    @optimize_execution("KBS")
    def symbols_by_industries(
        self,
        lang: str = "vi",
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve tickers grouped by industry. The industry codes are KBS's own scheme, not the more common ICB standard.

        Args:
            lang: Language, 'vi' or 'en'. Defaults to 'vi'.
            show_log: Show debug logs. Defaults to False.

        Returns:
            DataFrame of tickers with their industry.

        Raises:
            ValueError: If the language is not supported.
        """
        if lang not in ["vi", "en"]:
            raise ValueError("Ngôn ngữ phải là 'vi' hoặc 'en'.")

        # Get list of industries
        try:
            industries_data = self._get_industries_internal(show_log=show_log)
        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy danh sách ngành: {str(e)}")
            # Return empty DataFrame if API fails
            df = pd.DataFrame(columns=["symbol", "industry_code", "industry_name"])
            df.attrs["source"] = self.data_source
            return df

        all_symbols_by_industry = []

        for industry in industries_data:
            code = industry["code"]
            name = industry["name"]

            try:
                symbols = self._get_symbols_by_industry_internal(
                    industry_code=code, show_log=show_log
                )

                for symbol in symbols:
                    all_symbols_by_industry.append(
                        {
                            "symbol": symbol,
                            "industry_code": code,
                            "industry_name": name,
                        }
                    )
            except Exception as e:
                if show_log:
                    logger.warning(f"Lỗi khi lấy mã từ ngành {name} ({code}): {str(e)}")

        if all_symbols_by_industry:
            df = pd.DataFrame(all_symbols_by_industry)
            df.attrs["source"] = self.data_source
            return df
        else:
            df = pd.DataFrame(columns=["symbol", "industry_code", "industry_name"])
            df.attrs["source"] = self.data_source
            return df

    @optimize_execution("KBS")
    def symbols_by_group(
        self,
        group: str = "VN30",
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the tickers that make up an index or trade on an exchange.

        Supported groups: the VN indices (VN30, VN100, VNMidCap, VNSmallCap, VNSI, VNX50,
        VNXALL), the exchanges (HOSE, HNX, UPCOM), HNX30, ETFs, covered warrants (CW),
        bonds (BOND) and derivatives (DER).

        Call `get_supported_groups()` for the full list.

        Args:
            group: A supported group name. Defaults to 'VN30'.
                   For example 'VN30', 'VN100', 'HOSE', 'HNX', 'UPCOM', 'ETF', 'BOND', 'CW', 'FU_INDEX'.
            show_log: Show debug logs. Defaults to False.

        Returns:
            Series of tickers belonging to the group.

        Raises:
            ValueError: If the group name is not supported.

        Example:
            >>> from quant_master.explorer.kbs import Listing
            >>> kbs = Listing()
            >>> # Members of VN30
            >>> vn30 = kbs.symbols_by_group('VN30')
            >>> # Every ETF
            >>> etf_symbols = kbs.symbols_by_group('ETF')
            >>> # See every supported group
            >>> groups = kbs.get_supported_groups()
        """
        if group not in _GROUP_CODE:
            raise ValueError(
                "Nhóm không hợp lệ. Sử dụng get_supported_groups() để xem danh sách nhóm được hỗ trợ."
            )

        symbols = self._get_symbols_by_group_internal(group=group, show_log=show_log)

        series = pd.Series(symbols, name="symbol")
        series.attrs["source"] = self.data_source
        series.attrs["group"] = group
        return series

    @optimize_execution("KBS")
    def industries_icb(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.DataFrame:
        """
        Retrieve the ICB industry classification.

        Note: **KBS does not publish an ICB classification.**

        Use `symbols_by_industries()` to get tickers grouped by KBS's own industry codes.

        Raises:
            NotImplementedError: KBS does not support the ICB classification.
        """  # noqa: W293
        raise NotImplementedError(
            "KBS không cung cấp ICB classification. "
            "Sử dụng symbols_by_industries() để lấy mã theo ngành."
        )

    @optimize_execution("KBS")
    def get_supported_groups(
        self,
    ) -> pd.DataFrame:
        """
        List every group and exchange accepted by symbols_by_group().

        The index descriptions follow the vnstock naming convention.

        Returns:
            DataFrame with the columns:
            - group_name: the name to pass to symbols_by_group()
            - group_code: the code KBS uses internally
            - category: one of the categories listed in Vietnamese by the source
            - description: a fuller description, following the vnstock convention

        Example:
            >>> from quant_master.explorer.kbs import Listing
            >>> kbs = Listing()
            >>> groups = kbs.get_supported_groups()
            >>> print(groups)
            >>> # Keep the VN indices only
            >>> vn_indices = groups[groups['category'] == 'Chỉ số VN']
        """
        group_info = {
            # VN indices - descriptions follow the vnstock convention
            (
                "VN30",
                "30",
                "Chỉ số VN",
                "30 cổ phiếu vốn hóa lớn nhất & thanh khoản tốt nhất HOSE",
            ),
            ("VN100", "100", "Chỉ số VN", "100 cổ phiếu có vốn hoá lớn nhất HOSE"),
            (
                "VNMidCap",
                "MID",
                "Chỉ số VN",
                "Mid-Cap Index - nhóm cổ phiếu vốn hóa trung bình",
            ),
            (
                "VNSmallCap",
                "SML",
                "Chỉ số VN",
                "Small-Cap Index - nhóm cổ phiếu vốn hóa nhỏ",
            ),
            ("VNSI", "SI", "Chỉ số VN", "Vietnam Small-Cap Index"),
            (
                "VNX50",
                "X50",
                "Chỉ số VN",
                "50 cổ phiếu vốn hóa lớn nhất trên toàn bộ thị trường HOSE và HNX",
            ),
            (
                "VNXALL",
                "XALL",
                "Chỉ số VN",
                "Tất cả cổ phiếu trên toàn bộ thị trường HOSE và HNX",
            ),
            ("VNALL", "ALL", "Chỉ số VN", "Tất cả cổ phiếu trên HOSE và HNX"),
            ("HNX30", "HNX30", "Chỉ số VN", "Chỉ số 30 cổ phiếu hàng đầu HNX"),
            # Exchanges
            (
                "HOSE",
                "HOSE",
                "Sàn giao dịch",
                "Sở giao dịch chứng khoán TP. Hồ Chí Minh",
            ),
            ("HNX", "HNX", "Sàn giao dịch", "Sàn Giao dịch Chứng khoán Hà Nội"),
            (
                "UPCOM",
                "UPCOM",
                "Sàn giao dịch",
                "Sàn Giao dịch OTC (UPCoM - Unlisted Public Company Market)",
            ),
            # Funds and fund certificates
            (
                "ETF",
                "FUND",
                "ETF/Quỹ",
                "Exchange-Traded Fund - Quỹ chỉ số và quỹ trao đổi",
            ),
            # Covered warrants
            (
                "CW",
                "CW",
                "Chứng quyền",
                "Covered Warrant - Chứng quyền phát hành bởi các tổ chức tài chính",
            ),
            # Bonds
            (
                "BOND",
                "BOND",
                "Trái phiếu",
                "Corporate Bond - Trái phiếu doanh nghiệp niêm yết",
            ),
            # Derivatives
            ("FU_INDEX", "DER", "Phái sinh", "Futures - Hợp đồng tương lai chỉ số"),
        }

        data = [
            {
                "group_name": name,
                "group_code": code,
                "category": category,
                "description": desc,
            }
            for name, code, category, desc in sorted(group_info)
        ]

        df = pd.DataFrame(data)
        df.attrs["source"] = self.data_source
        return df

    @optimize_execution("KBS")
    def all_future_indices(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the list of futures contract symbols.

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            Series of futures symbols.
        """
        return self.symbols_by_group(group="FU_INDEX", show_log=show_log)

    @optimize_execution("KBS")
    def all_covered_warrant(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the list of covered warrant symbols.

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            Series of covered warrant symbols.
        """
        return self.symbols_by_group(group="CW", show_log=show_log)

    @optimize_execution("KBS")
    def all_bonds(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the list of bond symbols.

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            Series of bond symbols.
        """
        return self.symbols_by_group(group="BOND", show_log=show_log)

    @optimize_execution("KBS")
    def all_etf(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the list of ETF symbols.

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            Series of ETF symbols.
        """
        return self.symbols_by_group(group="ETF", show_log=show_log)

    @optimize_execution("KBS")
    def all_government_bonds(
        self,
        show_log: Optional[bool] = False,
    ) -> pd.Series:
        """
        Retrieve the list of government bond symbols.

        Note: **KBS does not publish government bond data.**

        Use `all_bonds()` for corporate bonds.

        Raises:
            NotImplementedError: KBS does not support government bonds.
        """
        raise NotImplementedError(
            "KBS không cung cấp dữ liệu trái phiếu chính phủ. "
            "Sử dụng all_bonds() để lấy trái phiếu doanh nghiệp."
        )

    # ===================== Internal methods =====================

    def _get_full_stock_data(
        self,
        show_log: Optional[bool] = False,
    ) -> List[Dict]:
        """
        Fetch the full record for every security from the /stock/search/data endpoint.

        Returns every field the source provides: symbol, name, nameEn, exchange,
        type, index, re, ceiling, floor.

        Args:
            show_log: Show debug logs. Defaults to False.

        Returns:
            List[Dict] with the full record for every security, or [] on failure.
        """  # noqa: W291
        url = _SEARCH_URL

        try:
            json_data = send_request(
                url=url,
                headers=self.headers,
                method="GET",
                payload=None,
                show_log=show_log,
            )

            if not json_data:
                raise ValueError("Không tìm thấy dữ liệu chứng khoán.")

            # KBS returns data in different formats
            if isinstance(json_data, list):
                stocks_data = json_data
            elif isinstance(json_data, dict) and "data" in json_data:
                stocks_data = json_data["data"]
            else:
                stocks_data = []

            if show_log:
                logger.info(f"Truy xuất thành công {len(stocks_data)} chứng khoán.")

            return stocks_data

        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy dữ liệu chứng khoán: {str(e)}")
            return []

    def _get_symbols_by_group_internal(
        self,
        group: str,
        show_log: Optional[bool] = False,
    ) -> List[str]:
        """
        Fetch the tickers belonging to a group or exchange.

        Args:
            group: Group or exchange name.
            show_log: Show debug logs.

        Returns:
            List[str] of tickers.
        """
        group_code = _GROUP_CODE.get(group, group)
        url = f"{_INDEX_URL}/{group_code}/stocks"

        try:
            json_data = send_request(
                url=url,
                headers=self.headers,
                method="GET",
                payload=None,
                show_log=show_log,
            )

            if not json_data:
                raise ValueError(f"Không tìm thấy dữ liệu cho nhóm {group}.")

            # KBS returns {"status": 200, "data": [...]}
            if isinstance(json_data, dict) and "data" in json_data:
                symbols = json_data["data"]
            elif isinstance(json_data, list):
                symbols = json_data
            else:
                symbols = []

            if show_log:
                logger.info(f"Truy xuất thành công {len(symbols)} mã từ nhóm {group}.")

            return symbols

        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy dữ liệu từ nhóm {group}: {str(e)}")
            raise

    def _get_industries_internal(
        self,
        show_log: Optional[bool] = False,
    ) -> List[Dict]:
        """
        Fetch the list of industries.

        Args:
            show_log: Show debug logs.

        Returns:
            List[Dict] describing each industry.
        """
        url = f"{_SECTOR_ALL_URL}"

        try:
            json_data = send_request(
                url=url,
                headers=self.headers,
                method="GET",
                payload=None,
                show_log=show_log,
            )

            if not json_data:
                raise ValueError("Không tìm thấy dữ liệu ngành.")

            # KBS returns a list of industries directly
            if isinstance(json_data, list):
                industries = json_data
            elif isinstance(json_data, dict) and "data" in json_data:
                industries = json_data["data"]
            else:
                industries = []

            if show_log:
                logger.info(f"Truy xuất thành công {len(industries)} ngành.")

            return industries

        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy danh sách ngành: {str(e)}")
            # Return empty list instead of raising to allow graceful degradation
            return []

    def _get_symbols_by_industry_internal(
        self,
        industry_code: int,
        show_log: Optional[bool] = False,
    ) -> List[str]:
        """
        Fetch the tickers belonging to one industry code.

        Args:
            industry_code: Industry code.
            show_log: Show debug logs.

        Returns:
            List[str] of tickers.
        """
        url = f"{_SECTOR_STOCK_URL}?code={industry_code}&l=1"

        try:
            json_data = send_request(
                url=url,
                headers=self.headers,
                method="GET",
                payload=None,
                show_log=show_log,
            )

            if not json_data:
                return []

            # Handle different response formats
            if isinstance(json_data, dict) and "stocks" in json_data:
                # Extract stock symbols from the stocks list
                stocks = json_data["stocks"]
                symbols = [stock["sb"] for stock in stocks if "sb" in stock]
            elif isinstance(json_data, dict) and "data" in json_data:
                symbols = json_data["data"]
            elif isinstance(json_data, list):
                symbols = json_data
            else:
                symbols = []

            if show_log:
                logger.info(
                    f"Truy xuất thành công {len(symbols)} mã từ ngành {industry_code}."
                )

            return symbols

        except Exception as e:
            if show_log:
                logger.error(f"Lỗi khi lấy mã từ ngành {industry_code}: {str(e)}")
            return []


# Register KBS Listing provider
from vnstock.core.registry import ProviderRegistry  # noqa: E402, F401

ProviderRegistry.register("listing", "kbs", Listing)
