"""Quote module for KB Securities (KBS) data source."""

import json
from datetime import datetime
from typing import Optional, Union

import pandas as pd
from vnai import optimize_execution

from vnstock.core.models import TickerModel
from vnstock.core.registry import ProviderRegistry  # noqa: E402, F401
from vnstock.core.utils.client import send_request
from vnstock.core.utils.logger import get_logger
from vnstock.core.utils.lookback import (
    get_start_date_from_lookback,
    interpret_lookback_length,
)
from vnstock.core.utils.parser import convert_derivative_symbol, get_asset_type
from vnstock.core.utils.transform import process_match_types
from vnstock.core.utils.user_agent import get_headers
from vnstock.explorer.kbs.const import (
    _IIS_BASE_URL,
    _INDEX_MAPPING,
    _INTERVAL_MAP,
    _INTRADAY_DTYPE,
    _INTRADAY_MAP,
    _OHLC_DTYPE,
    _OHLC_MAP,
)

logger = get_logger(__name__)


class Quote:
    """
    Access historical price data published by KB Securities (KBS).
    """

    def __init__(
        self,
        symbol: str,
        random_agent: Optional[bool] = False,
        show_log: Optional[bool] = False,
    ):
        """
        Initialise the KBS Quote client.

        Args:
            symbol: Ticker symbol, e.g. 'ACB' or 'VNM'.
            random_agent: Deprecated and ignored. Defaults to False.
            show_log: Show debug logs. Defaults to False.
        """
        self.symbol = symbol.upper()
        self.data_source = "KBS"
        self.asset_type = get_asset_type(self.symbol)

        # Auto-convert derivative symbols to new KRX format
        if self.asset_type == "derivative":
            try:
                # Try to convert if it matches old patterns (e.g. starts with VN30F)
                # The parser handles checks internally or via try/except
                new_symbol = convert_derivative_symbol(self.symbol)
                logger.info(
                    f"Converted derivative symbol {self.symbol} to {new_symbol} (KRX format)"
                )
                self.symbol = new_symbol
            except Exception as e:
                # If conversion fails (e.g. already new format or unsupported), keep original
                logger.debug(f"Symbol conversion skipped for {self.symbol}: {e}")

        self.base_url = _IIS_BASE_URL
        self.headers = get_headers(
            data_source=self.data_source, random_agent=random_agent
        )
        self.show_log = show_log
        self.interval_map = _INTERVAL_MAP

        if not show_log:
            logger.setLevel("CRITICAL")

        # Validate index symbols
        if self.asset_type == "index":
            if self.symbol not in _INDEX_MAPPING:
                valid_indices = ", ".join(_INDEX_MAPPING.keys())
                raise ValueError(
                    f"Mã chỉ số '{self.symbol}' không được hỗ trợ bởi KBS. "
                    f"Các chỉ số hợp lệ: {valid_indices}"
                )

    def _input_validation(
        self, start: Optional[str], end: str, interval: str
    ) -> TickerModel:
        """
        Validate input parameters.

        Args:
            start: Start date, YYYY-MM-DD or DD-MM-YYYY.
            end: End date, YYYY-MM-DD or DD-MM-YYYY.
            interval: Timeframe: 1m, 5m, 15m, 30m, 1H, 1D, 1W or 1M.

        Returns:
            A validated TickerModel instance.

        Raises:
            ValueError: If the interval is not supported.
        """
        ticker = TickerModel(
            symbol=self.symbol, start=start, end=end, interval=interval
        )

        if interval not in self.interval_map:
            valid_intervals = ", ".join(self.interval_map.keys())
            raise ValueError(
                f"Giá trị interval không hợp lệ: {interval}. "
                f"Vui lòng chọn: {valid_intervals}"
            )

        return ticker

    def _format_date_for_api(self, date_str: str) -> str:
        """
        Convert a date from YYYY-MM-DD to the DD-MM-YYYY the KBS API expects.

        Args:
            date_str: Date as YYYY-MM-DD.

        Returns:
            The same date as DD-MM-YYYY.
        """
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            return dt.strftime("%d-%m-%Y")
        except ValueError:
            # Already in DD-MM-YYYY, hand it back untouched
            return date_str

    @optimize_execution("KBS")
    def history(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None,
        interval: Optional[str] = "1D",
        to_df: Optional[bool] = True,
        show_log: Optional[bool] = False,
        count_back: Optional[int] = None,
        floating: Optional[int] = 2,
        length: Optional[Union[str, int]] = None,
        get_all: Optional[bool] = False,
    ) -> Union[pd.DataFrame, str]:
        """
        Load the price history of a symbol from KBS.

        Args:
            start: Start date, YYYY-MM-DD or DD-MM-YYYY. Required unless length or count_back is given.
            end: End date, YYYY-MM-DD or DD-MM-YYYY. Defaults to None, meaning up to now.
            interval: Timeframe: 1m, 5m, 15m, 30m, 1H, 1D, 1W or 1M. Defaults to "1D".
            to_df: Return a DataFrame. Defaults to True; False returns JSON.
            show_log: Show debug logs.
            count_back: Number of bars to return.
            floating: Decimal places for prices. Defaults to 2.
            length: Lookback window. Accepts a period string ('3M'), a day count (150 or '150') or a bar count ('100b').
            get_all: Return every column the API provides. Defaults to False, the standardised subset.

        Returns:
            DataFrame, or a JSON string, holding the OHLCV data.

        Examples:
            >>> quote = Quote('ACB')
            >>> df = quote.history(start='2024-01-01', end='2024-12-31', interval='1D')
            >>> print(df.columns.tolist())
            ['time', 'open', 'high', 'low', 'close', 'volume']

            >>> # Use length for the most recent month
            >>> df_1m = quote.history(length='1M', interval='1D')

            >>> # Fetch 100 bars
            >>> df_100 = quote.history(count_back=100, interval='1D')

            >>> # Fetch 150 days
            >>> df_150d = quote.history(length=150, interval='1D')

            >>> # Three months ending on a given date
            >>> df_3m = quote.history(end='2024-12-31', length='3M', interval='1D')

            >>> # Every column, including value
            >>> df_all = quote.history(length='1M', interval='1D', get_all=True)
        """  # noqa: W293
        # Set end date to today if not provided
        if end is None:
            end = datetime.now().strftime("%Y-%m-%d")

        # Calculate start if not provided
        if start is None:
            # Check if length defines bars
            if length is not None:
                bars_from_len, len_remainder = interpret_lookback_length(length)
                if bars_from_len is not None:
                    count_back = bars_from_len
                    length = None  # Consumed as bars
                else:
                    length = len_remainder

            if length is not None:
                start = get_start_date_from_lookback(
                    lookback_length=length, end_date=end
                )
            elif count_back is not None:
                # For count_back, calculate start date based on interval and bars
                start = get_start_date_from_lookback(
                    bars=count_back, interval=interval, end_date=end
                )
            else:
                raise ValueError(
                    "Tham số 'start' là bắt buộc nếu không cung cấp "
                    "'length' hoặc 'count_back'."
                )

        # Validate inputs (only if start is provided)
        if start is not None:
            ticker = self._input_validation(start, end, interval)
        else:
            # Create a minimal ticker model for validation of interval only
            # Use end as start temporarily since start is None
            ticker = TickerModel(
                symbol=self.symbol, start=end, end=end, interval=interval
            )
            # Override start with None for later processing
            ticker.start = start

        # Convert dates to KBS format (DD-MM-YYYY)
        start_date_kbs = self._format_date_for_api(start)  # Use calculated start
        end_date_kbs = self._format_date_for_api(end)

        # Get the KBS API endpoint suffix for the interval
        interval_suffix = self.interval_map[interval]

        # Build URL based on asset type
        if self.asset_type == "index":
            url = f"{_IIS_BASE_URL}/index/{self.symbol}/data_{interval_suffix}"
        else:
            url = f"{_IIS_BASE_URL}/stocks/{self.symbol}/data_{interval_suffix}"
        params = {
            "sdate": start_date_kbs,
            "edate": end_date_kbs,
        }

        # Make API request
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            show_log=show_log or self.show_log,
        )

        if not json_data:
            raise ValueError(
                f"Không tìm thấy dữ liệu cho mã {self.symbol}. "
                "Vui lòng kiểm tra lại mã chứng khoán hoặc khoảng thời gian."
            )

        # Extract OHLC data based on interval
        data_key = f"data_{interval_suffix}"
        if data_key not in json_data:
            raise ValueError(
                f"Không tìm thấy dữ liệu cho interval {interval}. "
                f"Vui lòng kiểm tra lại khoảng thời gian hoặc interval."
            )

        ohlc_data = json_data[data_key]

        if not ohlc_data:
            raise ValueError(
                f"Dữ liệu trống cho mã {self.symbol} với interval {interval}."
            )

        if not to_df:
            return json.dumps(ohlc_data)

        # Convert to DataFrame
        df = pd.DataFrame(ohlc_data)

        # Handle 'va' column - remove from standard output, keep as 'value' if get_all=True
        # Rename columns first
        df = df.rename(columns=_OHLC_MAP)

        # If not get_all, strictly keep only standard columns
        if not get_all:
            base_cols = ["time", "open", "high", "low", "close", "volume"]
            existing_cols = [c for c in base_cols if c in df.columns]
            df = df[existing_cols]
        # logic for 'value' column is already handled by _OHLC_MAP if 'va' maps to 'value',
        # or we accept that strict mode excludes it unless 'value' is inherently part of standard set (usually not)

        # Convert time column to datetime
        df["time"] = pd.to_datetime(df["time"])

        # Sort by time
        df = df.sort_values("time").reset_index(drop=True)

        # Set data types
        for col, dtype in _OHLC_DTYPE.items():
            if col in df.columns:
                try:
                    df[col] = df[col].astype(dtype)
                except ValueError:
                    # Handle cases where API returns float string for int (e.g. '100.0')
                    df[col] = df[col].astype(float).astype(dtype)

        # Set data type for 'value' column if present
        if "value" in df.columns:
            df["value"] = df["value"].astype("float64")

        # Apply floating point precision to OHLC columns
        ohlc_cols = ["open", "high", "low", "close"]
        for col in ohlc_cols:
            if col in df.columns:
                # Only divide by 1000 for stock and ETF assets
                # Derivatives and Indices are already quoted in points/full value.
                if self.asset_type not in ["derivative", "index"]:
                    df[col] = df[col] / 1000

                if floating is not None:
                    df[col] = df[col].round(floating)

        # Trim data to start time if needed
        df = df[df["time"] >= pd.to_datetime(start)].reset_index(drop=True)

        # Apply count_back if specified
        if count_back is not None:
            df = df.tail(count_back).reset_index(drop=True)

        # Add metadata
        df.attrs["symbol"] = self.symbol
        df.attrs["source"] = self.data_source
        df.attrs["interval"] = interval
        df.attrs["start"] = start
        df.attrs["end"] = end
        df.attrs["length"] = length

        if show_log or self.show_log:
            logger.info(
                f"Truy xuất thành công {len(df)} bản ghi giá cho {self.symbol} "
                f"({interval}) từ {start_date_kbs} đến {end_date_kbs}."
            )

        return df

    @optimize_execution("KBS")
    def intraday(
        self,
        page_size: Optional[int] = 100,
        page: Optional[int] = 1,
        to_df: Optional[bool] = True,
        get_all: Optional[bool] = False,
        show_log: Optional[bool] = False,
        floating: Optional[int] = 2,
    ) -> Union[pd.DataFrame, str]:
        """
        Retrieve in-session matched trades for a symbol from KBS.

        Returns the standardised columns (time, price, volume, match_type, id) by default.
        Pass get_all=True for every column the API provides.

        Args:
            page_size: Records per page. Defaults to 100.
                       A single session can run to 100K rows for VN30 derivatives, or 50-70K for a stock.
            page: Page number. Defaults to 1.
            to_df: Return a DataFrame. Defaults to True; False returns JSON.
            get_all: Return every column the API provides. Defaults to False, the standardised subset.
            show_log: Show debug logs.
            floating: Decimal places for prices. Defaults to 2; None leaves them unrounded.

        Returns:
            DataFrame, or a JSON string, holding the matched trades.

            **Core columns:**
            - time: Trade time (YYYY-MM-DD HH:MM:SS)
            - price: Matched price
            - volume: Matched volume
            - match_type: Match type (buy, sell, atc, ato)
            - id: Trade id, built by KBS from timestamp, price and volume

            **Additional columns when get_all=True:**
            - trading_date: Trading date (DD/MM/YYYY)
            - symbol: Ticker symbol
            - price_change: Change against the previous trade
            - accumulated_volume: Cumulative volume
            - accumulated_value: Cumulative value

        Examples:
            >>> quote = Quote('ACB')

            >>> # 100 records, standardised columns
            >>> df = quote.intraday(page_size=100)

            >>> # Second page
            >>> df_page2 = quote.intraday(page=2, page_size=100)

            >>> # Every column
            >>> df_all = quote.intraday(get_all=True)
        """  # noqa: W293
        # Validator: Intraday data is not supported for indices
        if self.asset_type == "index":
            raise ValueError(
                f"Dữ liệu intraday không được hỗ trợ cho chỉ số {self.symbol}."
            )

        # Build URL for intraday trade history
        url = f"{_IIS_BASE_URL}/trade/history/{self.symbol}"

        # Add pagination parameters
        params = {
            "page": page,
            "limit": page_size,
        }

        # Make API request
        json_data = send_request(
            url=url,
            headers=self.headers,
            method="GET",
            params=params,
            show_log=show_log or self.show_log,
        )

        if not json_data or "data" not in json_data:
            raise ValueError(
                f"Không tìm thấy dữ liệu intraday cho mã {self.symbol}. "
                "Vui lòng kiểm tra lại mã chứng khoán hoặc thử lại sau."
            )

        intraday_data = json_data.get("data", [])

        if not intraday_data:
            raise ValueError(f"Dữ liệu intraday trống cho mã {self.symbol}.")

        if not to_df:
            return json.dumps(intraday_data)

        # Convert to DataFrame
        df = pd.DataFrame(intraday_data)

        # Rename columns using mapping
        df = df.rename(columns=_INTRADAY_MAP)

        # Convert timestamp to datetime
        # KBS format: "2026-01-14 14:27:23:15" (with milliseconds as :MS instead of .MS)
        if "timestamp" in df.columns:
            df["timestamp"] = df["timestamp"].apply(
                lambda x: (
                    pd.to_datetime(x.rsplit(":", 1)[0]) if isinstance(x, str) else x
                )
            )

        # Set data types
        for col, dtype in _INTRADAY_DTYPE.items():
            if col in df.columns:
                try:
                    df[col] = df[col].astype(dtype)
                except (ValueError, TypeError):
                    # Keep original type if conversion fails
                    pass

        # Sort by timestamp (newest first)
        df = df.sort_values("timestamp", ascending=False).reset_index(drop=True)

        # Create standardized DataFrame with core columns
        standardized_df = pd.DataFrame()

        # time: Full timestamp (YYYY-MM-DD HH:MM:SS)
        if "timestamp" in df.columns:
            standardized_df["time"] = df["timestamp"]

        # price: Match price
        if "price" in df.columns:
            # Only divide by 1000 for non-derivative and non-index assets
            if self.asset_type not in ["derivative", "index"]:
                standardized_df["price"] = df["price"] / 1000
            else:
                standardized_df["price"] = df["price"]

            if floating is not None:
                standardized_df["price"] = standardized_df["price"].round(floating)

        # volume: Match volume (KBS uses 'match_volume')
        if "match_volume" in df.columns:
            standardized_df["volume"] = df["match_volume"]

        # match_type: Trade side ('B' = buy, 'S' = sell)
        # Use existing process_match_types utility for ATO/ATC logic
        if "side" in df.columns:
            # Map KBS side values to match_type format
            standardized_df["match_type"] = df["side"].fillna("")

        # Apply the standard process_match_types function
        if "match_type" in standardized_df.columns:
            # Ensure time column is datetime for process_match_types
            standardized_df["time"] = pd.to_datetime(standardized_df["time"])
            standardized_df = process_match_types(
                standardized_df, asset_type=self.asset_type, source="KBS"
            )
            # Convert to lowercase for final output
            standardized_df["match_type"] = (
                standardized_df["match_type"].astype(str).str.lower()
            )

        # id: Generate ID from timestamp, price, and volume (KBS doesn't have transaction ID)
        if "timestamp" in df.columns:
            # Create unique ID combining timestamp, price, and volume
            standardized_df["id"] = (
                df["timestamp"].astype(str).str.replace(" ", "_").str.replace(":", "")
                + "_"
                + df["price"].astype(str).str.replace(".", "")
                + "_"
                + df["match_volume"].astype(str)
            )

        # Select columns based on get_all parameter
        if get_all:
            # Add all KBS-specific columns to standardized columns
            kbs_specific_cols = [
                "trading_date",
                "symbol",
                "price_change",
                "accumulated_volume",
                "accumulated_value",
            ]
            for col in kbs_specific_cols:
                if col in df.columns:
                    standardized_df[col] = df[col]
            result_df = standardized_df
        else:
            # Return only core standardized columns
            result_df = standardized_df[["time", "price", "volume", "match_type", "id"]]

        # Add metadata
        result_df.attrs["symbol"] = self.symbol
        result_df.attrs["source"] = self.data_source
        result_df.attrs["page"] = page
        result_df.attrs["page_size"] = page_size
        result_df.attrs["get_all"] = get_all

        if show_log or self.show_log:
            logger.info(
                f"Truy xuất thành công {len(result_df)} bản ghi khớp lệnh intraday cho {self.symbol} "
                f"(trang {page}, page_size={page_size})."
            )

        return result_df


# Register KBS Quote provider
ProviderRegistry.register("quote", "kbs", Quote)
