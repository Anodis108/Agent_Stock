import inspect
from abc import ABC
from functools import wraps
from typing import Optional

from vnstock.core.registry import ProviderRegistry
from vnstock.core.utils.retry import api_retry


def dynamic_method(func):
    """
    Decorator for adapter methods:
    - Calls the original function (allowing for parameter mapping/logic)
    - If the function returns None (e.g. 'pass'), falls back to automatic delegation
    - Ensures the loaded provider supports this method
    - Filters kwargs to only those the provider’s signature accepts
    """
    method_name = func.__name__

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        # 1. Try calling the decorated function first (custom logic)
        result = func(self, *args, **kwargs)
        if result is not None:
            return result

        # 2. Automated delegation fallback
        if not hasattr(self._provider, method_name):
            raise NotImplementedError(
                f"Source '{self.source}' does not support '{method_name}'"
            )

        provider_method = getattr(self._provider, method_name)
        sig = inspect.signature(provider_method)
        filtered = {k: v for k, v in kwargs.items() if k in sig.parameters}
        return provider_method(*args, **filtered)

    return wrapper


class BaseAdapter(ABC):
    """
    Base adapter that uses ProviderRegistry to discover and instantiate
    providers from both explorer and connector packages.
    """

    _module_name: str  # e.g. "quote", "company", etc.

    def __init__(self, source: str, symbol: Optional[str] = None, **kwargs):
        # Preserve original for error messages
        self.source = source
        self.symbol = symbol
        self._init_kwargs = kwargs  # Store for re-initialization

        # Get provider class from registry
        try:
            impl_cls = ProviderRegistry.get(self._module_name, source)
        except ValueError as e:
            raise ValueError(str(e)) from e

        # Inspect constructor signature and filter kwargs
        sig = inspect.signature(impl_cls.__init__)
        init_params = {}
        # Only pass symbol if accepted (handle both 'symbol' and 'symbol_id' names)
        if symbol is not None:
            if "symbol" in sig.parameters:
                init_params["symbol"] = symbol
            elif "symbol_id" in sig.parameters:
                init_params["symbol_id"] = symbol
        # Pass only recognized provider kwargs
        for key, val in kwargs.items():
            if key in sig.parameters:
                init_params[key] = val

        # Instantiate the provider
        self._provider = impl_cls(**init_params)

    @property
    def provider(self):
        """Access the underlying explorer/connector provider."""
        return self._provider

    def _update_provider(self):
        """Re-initialize the provider if source or symbol has changed."""
        self.__init__(source=self.source, symbol=self.symbol, **self._init_kwargs)

    def __getattr__(self, name):
        # Delegate attribute access to the provider
        return getattr(self._provider, name)

    @api_retry
    def history(self, *args, **kwargs):
        # Generic retry wrapper for any .history() calls
        return self._provider.history(*args, **kwargs)
